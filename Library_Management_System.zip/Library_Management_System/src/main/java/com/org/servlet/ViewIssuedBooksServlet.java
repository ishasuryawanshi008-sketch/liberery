package com.org.servlet;

import com.org.dao.IssueDAO;
import com.org.model.IssuedBook;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/member/issued-books")
public class ViewIssuedBooksServlet extends HttpServlet {

    private IssueDAO issueDao = new IssueDAO();

    @Override
    protected void doGet(javax.servlet.http.HttpServletRequest request,
                         javax.servlet.http.HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        int memberId = (int) session.getAttribute("userId");
        List<IssuedBook> list = issueDao.getIssuedBooksByMember(memberId);
        request.setAttribute("issuedList", list);
        request.getRequestDispatcher("/member/issued-books.jsp").forward(request, response);
    }
}

