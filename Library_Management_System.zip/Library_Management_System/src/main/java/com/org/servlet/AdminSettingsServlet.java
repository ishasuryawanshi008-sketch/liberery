package com.org.servlet;

import com.org.dao.AdminDAO;
import com.org.model.Admin;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/AdminSettingsServlet")
public class AdminSettingsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        AdminDAO dao = new AdminDAO();
        Admin admin = dao.getFirstAdmin();
        req.setAttribute("admin", admin);
        RequestDispatcher rd = req.getRequestDispatcher("admin/settings.jsp");
        rd.forward(req, resp);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            int id = Integer.parseInt(req.getParameter("id"));
            String name = req.getParameter("name");
            String email = req.getParameter("email");
            String password = req.getParameter("password");
            String phone = req.getParameter("phone");
            String address = req.getParameter("address");

            Admin admin = new Admin(id, name, email, password, phone, address);

            AdminDAO dao = new AdminDAO();
            boolean ok = dao.updateAdmin(admin);

            if(ok) resp.sendRedirect(req.getContextPath() + "/admin/settings.jsp?msg=success");
            else resp.sendRedirect(req.getContextPath() + "/admin/settings.jsp?msg=error");

        } catch(Exception e) {
            e.printStackTrace();
            resp.sendRedirect(req.getContextPath() + "/admin/settings.jsp?msg=error");
        }
    }
}


