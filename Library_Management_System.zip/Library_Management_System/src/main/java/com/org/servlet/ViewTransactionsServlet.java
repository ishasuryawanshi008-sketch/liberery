package com.org.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import java.util.List;

import com.org.dao.IssueDAO;
import com.org.model.Issue;

@WebServlet("/ViewTransactionsServlet")
public class ViewTransactionsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);

        boolean isMember = session != null && session.getAttribute("memberId") != null;

        try {
            IssueDAO dao = new IssueDAO();
            List<Issue> transactions;

            if (isMember) {
                int memberId = Integer.parseInt(session.getAttribute("memberId").toString());
                transactions = dao.getTransactionsByMember(memberId);
            } else {
                transactions = dao.getAllTransactions();
            }

            req.setAttribute("transactions", transactions);

            String page = isMember
                    ? "/member/view-transactions.jsp"
                    : "/admin/view-transactions.jsp";

            req.getRequestDispatcher(page).forward(req, resp);

        } catch (Exception e) {
            e.printStackTrace();

            String errorPage = isMember
                    ? "/member/view-transactions.jsp?msg=error"
                    : "/admin/view-transactions.jsp?msg=error";

            resp.sendRedirect(req.getContextPath() + errorPage);
        }
    }
}
