package com.org.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import com.org.dao.AdminDAO;

@WebServlet("/AdminRegisterServlet")
public class AdminRegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        AdminDAO dao = new AdminDAO();
        boolean f = dao.registerAdmin(name, email, password);

        if(f) {
            resp.sendRedirect("admin/admin-login.jsp?msg=registered");
        } else {
            resp.sendRedirect("admin/admin-register.jsp?msg=exists");
        }
    }
}
