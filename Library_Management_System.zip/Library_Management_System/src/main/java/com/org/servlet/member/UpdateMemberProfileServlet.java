package com.org.servlet.member;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.org.dao.DBConnect;

@WebServlet("/member/UpdateMemberProfileServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 1, // 1MB
                 maxFileSize = 1024 * 1024 * 5,      // 5MB
                 maxRequestSize = 1024 * 1024 * 10) // 10MB
public class UpdateMemberProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.getWriter().println("UpdateMemberProfileServlet is running!");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("memberEmail") == null) {
            response.sendRedirect(request.getContextPath() + "/member-login-page.jsp?msg=loginfirst");
            return;
        }

        String memberEmail = (String) session.getAttribute("memberEmail");
        String fullName = request.getParameter("fullName");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");

        Part filePart = request.getPart("profileImg");
        String fileName = null;

        // Save uploaded images automatically
        String uploadPath = getServletContext().getRealPath("") + File.separator + "member/profile-img";
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdirs();

        if (filePart != null && filePart.getSize() > 0) {
            fileName = new File(filePart.getSubmittedFileName()).getName();
            String filePath = uploadPath + File.separator + fileName;
            filePart.write(filePath);
        }

        try {
            Connection con = DBConnect.getConnection();

            String sql;
            if (fileName != null) {
                sql = "UPDATE user_accounts SET full_name=?, phone=?, address=?, profile_img=? WHERE email=?";
            } else {
                sql = "UPDATE user_accounts SET full_name=?, phone=?, address=? WHERE email=?";
            }

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, fullName);
            ps.setString(2, phone);
            ps.setString(3, address);

            if (fileName != null) ps.setString(4, fileName);

            if (fileName != null) {
                ps.setString(5, memberEmail);
            } else {
                ps.setString(4, memberEmail);
            }

            int updated = ps.executeUpdate();

            if (updated > 0) {
                response.sendRedirect(request.getContextPath() + "/member/member-profile-page.jsp?msg=ProfileUpdated");
            } else {
                response.sendRedirect(request.getContextPath() + "/member/member-profile-page.jsp?msg=ErrorUpdating");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/member/member-profile-page.jsp?msg=Exception");
        }
    }
}
