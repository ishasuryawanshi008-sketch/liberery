package com.org.servlet;

import com.org.dao.UserDAO;
import com.org.dao.DBConnect;
import com.org.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.File;
import java.io.IOException;

@WebServlet("/UserServlet")
@MultipartConfig
public class UserServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String action = req.getParameter("action");

        switch (action) {

            case "login":
                loginUser(req, resp);
                break;

            case "register":
                registerUser(req, resp);
                break;

            case "updateProfile":
                updateProfile(req, resp);
                break;

            case "updateStatus":
                updateStatus(req, resp);
                break;

            case "deleteUser":
                deleteUser(req, resp);
                break;

            default:
                resp.sendRedirect("error.jsp");
        }
    }

    // -------------------------------
    // USER LOGIN
    // -------------------------------
    private void loginUser(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        String email = req.getParameter("email");
        String password = req.getParameter("password");

        UserDAO dao = new UserDAO(DBConnect.getConnection());

        User user = dao.login(email, password);

        if (user != null) {

            HttpSession session = req.getSession();
            session.setAttribute("userObj", user);

            if (user.getRole().equals("admin")) {
                resp.sendRedirect("admin/index.jsp");
            } else {
                resp.sendRedirect("member/index.jsp");
            }

        } else {
            HttpSession session = req.getSession();
            session.setAttribute("loginError", "Invalid Email or Password");
            resp.sendRedirect("login.jsp");
        }
    }

    // -------------------------------
    // REGISTER USER
    // -------------------------------
    private void registerUser(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {

        String fullName = req.getParameter("fullName");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String phone = req.getParameter("phone");
        String address = req.getParameter("address");
        String role = req.getParameter("role");
        String status = req.getParameter("status");

        Part imgPart = req.getPart("profileImg");
        String imgName = imgPart.getSubmittedFileName();

        String uploadPath = req.getServletContext().getRealPath("") + "assets/profile/";

        File file = new File(uploadPath);
        if (!file.exists()) file.mkdirs();

        imgPart.write(uploadPath + imgName);

        User user = new User();
        user.setFullName(fullName);
        user.setEmail(email);
        user.setPassword(password);
        user.setPhone(phone);
        user.setAddress(address);
        user.setRole(role);
        user.setStatus(status);
        user.setProfileImg(imgName);

        UserDAO dao = new UserDAO(DBConnect.getConnection());
        boolean f = dao.registerUser(user);

        HttpSession session = req.getSession();

        if (f) {
            session.setAttribute("successMsg", "User Registered Successfully!");
        } else {
            session.setAttribute("errorMsg", "Something went wrong!");
        }

        resp.sendRedirect("admin/add-user.jsp");
    }

    // -------------------------------
    // UPDATE PROFILE (MEMBER PANEL)
    // -------------------------------
    private void updateProfile(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {

        int id = Integer.parseInt(req.getParameter("id"));

        String fullName = req.getParameter("fullName");
        String phone = req.getParameter("phone");
        String address = req.getParameter("address");

        Part imgPart = req.getPart("profileImg");
        String imgName = imgPart.getSubmittedFileName();

        String uploadPath = req.getServletContext().getRealPath("") + "assets/profile/";
        File file = new File(uploadPath);
        if (!file.exists()) file.mkdirs();

        if (!imgName.equals("")) {
            imgPart.write(uploadPath + imgName); // upload new image
        } else {
            imgName = req.getParameter("oldImg"); // keep old image
        }

        User user = new User();
        user.setId(id);
        user.setFullName(fullName);
        user.setPhone(phone);
        user.setAddress(address);
        user.setProfileImg(imgName);

        UserDAO dao = new UserDAO(DBConnect.getConnection());

        boolean f = dao.updateProfile(user);

        HttpSession session = req.getSession();

        if (f) {
            session.setAttribute("successMsg", "Profile Updated Successfully");
        } else {
            session.setAttribute("errorMsg", "Profile Update Failed");
        }

        // refresh session user object
        User updatedUser = dao.getUserById(id);
        session.setAttribute("userObj", updatedUser);

        resp.sendRedirect("member/profile.jsp");
    }

    // -------------------------------
    // UPDATE USER STATUS (ADMIN)
    // -------------------------------
    private void updateStatus(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        int id = Integer.parseInt(req.getParameter("id"));
        String status = req.getParameter("status");

        UserDAO dao = new UserDAO(DBConnect.getConnection());
        boolean f = dao.updateUserStatus(id, status);

        HttpSession session = req.getSession();

        if (f) {
            session.setAttribute("successMsg", "Status Updated Successfully");
        } else {
            session.setAttribute("errorMsg", "Failed to Update Status");
        }

        resp.sendRedirect("admin/manage-users.jsp");
    }

    // -------------------------------
    // DELETE USER (ADMIN)
    // -------------------------------
    private void deleteUser(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        int id = Integer.parseInt(req.getParameter("id"));

        UserDAO dao = new UserDAO(DBConnect.getConnection());
        boolean f = dao.deleteUser(id);

        HttpSession session = req.getSession();

        if (f) {
            session.setAttribute("successMsg", "User Deleted Successfully");
        } else {
            session.setAttribute("errorMsg", "Failed to Delete User");
        }

        resp.sendRedirect("admin/manage-users.jsp");
    }

    // -------------------------------
    // PROCESS GET REQUEST → LOGOUT
    // -------------------------------
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        String action = req.getParameter("action");

        if ("logout".equals(action)) {
            HttpSession session = req.getSession();
            session.invalidate();
            resp.sendRedirect("login.jsp");
        } else {
            resp.sendRedirect("error.jsp");
        }
    }
}
