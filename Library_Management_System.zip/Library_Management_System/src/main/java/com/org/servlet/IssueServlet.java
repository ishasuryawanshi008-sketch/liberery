package com.org.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.org.dao.BookDAO;
import com.org.dao.IssueDAO;

@WebServlet("/IssueServlet")
public class IssueServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int memberId = Integer.parseInt(request.getParameter("member_id"));
            int bookId = Integer.parseInt(request.getParameter("book_id"));
            String issueDateStr = request.getParameter("issue_date");
            String dueDateStr = request.getParameter("due_date");

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date issueDate = sdf.parse(issueDateStr);
            Date dueDate = sdf.parse(dueDateStr);

            BookDAO bookDao = new BookDAO();
            IssueDAO issueDao = new IssueDAO();

            // Check if book has available copies
            if (bookDao.getAvailableCopies(bookId) <= 0) {
                response.sendRedirect("admin/issue-book.jsp?msg=nobook");
                return;
            }

            // Issue book
            boolean issued = issueDao.issueBook(memberId, bookId, issueDate, dueDate);
            if (issued) {
                // Decrease available copies
                bookDao.decreaseCopies(bookId);
                response.sendRedirect("admin/issue-book.jsp?msg=success");
            } else {
                response.sendRedirect("admin/issue-book.jsp?msg=error");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("admin/issue-book.jsp?msg=error");
        }
    }
}



