package com.org.servlet;

import com.org.dao.BookDAO;
import com.org.model.Book;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/admin/book")
public class BookServlet extends HttpServlet {

    private BookDAO bdao = new BookDAO();

    @Override
    protected void doGet(javax.servlet.http.HttpServletRequest request,
                         javax.servlet.http.HttpServletResponse response) throws ServletException, IOException {

        String action = request.getParameter("action");
        String idStr = request.getParameter("id");

        try {
            if ("delete".equals(action) && idStr != null) {
                int id = Integer.parseInt(idStr);
                boolean deleted = bdao.deleteBook(id);
                if (deleted) {
                    request.getSession().setAttribute("msg", "Book deleted successfully");
                } else {
                    request.getSession().setAttribute("error", "Could not delete book (maybe FK constraint)");
                }
                response.sendRedirect(request.getContextPath() + "/admin/manage-books.jsp");
                return;
            }

            // default: show single book if id passed
            if (idStr != null) {
                int id = Integer.parseInt(idStr);
                Book b = bdao.getBookById(id);
                request.setAttribute("book", b);
                request.getRequestDispatcher("/admin/edit-book.jsp").forward(request, response);
                return;
            }

            // otherwise forward to list page (JSP should call BookDAO if needed)
            response.sendRedirect(request.getContextPath() + "/admin/manage-books.jsp");

        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    // if you have create/update forms posting to this servlet, implement doPost
}
