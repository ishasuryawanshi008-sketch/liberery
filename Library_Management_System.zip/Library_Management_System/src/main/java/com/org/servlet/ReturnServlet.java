package com.org.servlet;

import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.org.dao.BookDAO;
import com.org.dao.IssueDAO;
import com.org.dao.FineDAO;

@WebServlet("/ReturnServlet")
public class ReturnServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int issueId = Integer.parseInt(request.getParameter("issue_id")); // Use issue_id, not member_id + book_id
            String returnDateStr = request.getParameter("return_date");

            // Convert to java.util.Date
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date returnDate = sdf.parse(returnDateStr);

            IssueDAO issueDao = new IssueDAO();
            BookDAO bookDao = new BookDAO();
            FineDAO fineDao = new FineDAO();

            // 1️⃣ Mark book as returned
            boolean success = issueDao.returnBook(issueId, returnDate);

            if(success){
                // 2️⃣ Increase book copies
                int bookId = bookDao.getBookIdByIssue(issueId);
                bookDao.increaseCopies(bookId);

                // 3️⃣ Check if book is late
                Date dueDate = issueDao.getDueDate(issueId);
                if(new Date(returnDate.getTime()).after(dueDate)){
                    long diff = returnDate.getTime() - dueDate.getTime();
                    long daysLate = diff / (1000*60*60*24);
                    double fineAmount = daysLate * 10; // Rs.10 per day

                    // 4️⃣ Add fine
                    fineDao.addFineByIds(issueId, fineAmount); // Make sure FineDAO has addFineByIds(int issueId, double fine)
                }

                response.sendRedirect("admin/return-book.jsp?msg=success");
            } else {
                response.sendRedirect("admin/return-book.jsp?msg=error");
            }

        } catch(Exception e){
            e.printStackTrace();
            response.sendRedirect("admin/return-book.jsp?msg=error");
        }
    }
}


