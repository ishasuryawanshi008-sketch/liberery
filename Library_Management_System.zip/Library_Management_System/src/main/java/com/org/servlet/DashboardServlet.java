package com.org.servlet ;

import com.org.dao.DBConnect;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/DashboardServlet")
public class DashboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (Connection con = DBConnect.getConnection()) {
            Statement st = con.createStatement();

            ResultSet r1 = st.executeQuery("SELECT COUNT(*) AS c FROM books");
            r1.next();
            request.setAttribute("books", r1.getInt("c"));

            ResultSet r2 = st.executeQuery("SELECT COUNT(*) AS c FROM members");
            r2.next();
            request.setAttribute("members", r2.getInt("c"));

            ResultSet r3 = st.executeQuery("SELECT COUNT(*) AS c FROM issues WHERE return_date IS NULL");
            r3.next();
            request.setAttribute("issued", r3.getInt("c"));

            ResultSet r4 = st.executeQuery("SELECT COUNT(*) AS c FROM fines");
            r4.next();
            request.setAttribute("fines", r4.getInt("c"));

        } catch (Exception e) {
            e.printStackTrace();
        }

        RequestDispatcher rd = request.getRequestDispatcher("dashboard.jsp");
        rd.forward(request, response);
    }
}
