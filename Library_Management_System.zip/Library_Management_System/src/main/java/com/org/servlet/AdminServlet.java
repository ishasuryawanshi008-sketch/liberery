package com.org.servlet;

import com.org.dao.AdminDAO;
import com.org.model.Admin;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/adminLogin")
public class AdminServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String email = req.getParameter("email");
        String password = req.getParameter("password");

        AdminDAO dao = new AdminDAO();
        Admin admin = dao.login(email, password);

        if (admin != null) {
            HttpSession session = req.getSession();
            session.setAttribute("adminObj", admin);
            resp.sendRedirect("admin/admin-dashboard.jsp");
        } else {
            HttpSession session = req.getSession();
            session.setAttribute("errorMsg", "Invalid Credentials");
            resp.sendRedirect("admin-login.jsp");
        }
    }
}

