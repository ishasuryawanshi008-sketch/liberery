package com.org.servlet;

import com.org.dao.MemberDAO;
import com.org.model.Member;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/MemberServlet")
public class MemberServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        String action = req.getParameter("action");
        MemberDAO mdao = new MemberDAO();

        // -------------------------
        // UPDATE STATUS
        // -------------------------
        if ("status".equals(action)) {
            int id = Integer.parseInt(req.getParameter("id"));
            String status = req.getParameter("status");

            boolean updated = mdao.updateStatus(id, status);

            if (updated) {
                resp.sendRedirect("admin/manage-members.jsp?msg=Status Updated Successfully");
            } else {
                resp.sendRedirect("admin/manage-members.jsp?msg=Failed to Update Status");
            }
            return;
        }

        // -------------------------
        // DELETE MEMBER
        // -------------------------
        if ("delete".equals(action)) {

            int id = Integer.parseInt(req.getParameter("id"));
            boolean deleted = mdao.deleteMember(id);

            if (deleted) {
                resp.sendRedirect("admin/manage-members.jsp?msg=Member Deleted Successfully");
            } else {
                resp.sendRedirect("admin/manage-members.jsp?msg=Failed to Delete Member");
            }
            return;
        }

        // -------------------------
        // ADD MEMBER
        // -------------------------
        if ("add".equals(action)) {
            String name = req.getParameter("name");
            String email = req.getParameter("email");
            String phone = req.getParameter("phone");
            String address = req.getParameter("address");

            Member m = new Member();
            m.setName(name);
            m.setEmail(email);
            m.setPhone(phone);
            m.setAddress(address);
            m.setStatus("active"); // default

            boolean saved = mdao.addMember(m);

            if (saved) {
                resp.sendRedirect("admin/manage-members.jsp?msg=Member Added Successfully");
            } else {
                resp.sendRedirect("admin/add-member.jsp?msg=Failed to Add Member");
            }
            return;
        }

        // -------------------------
        // EDIT MEMBER
        // -------------------------
        if ("edit".equals(action)) {

            int id = Integer.parseInt(req.getParameter("id"));
            String name = req.getParameter("name");
            String email = req.getParameter("email");
            String phone = req.getParameter("phone");
            String address = req.getParameter("address");
            String status = req.getParameter("status");

            Member m = new Member();
            m.setId(id);
            m.setName(name);
            m.setEmail(email);
            m.setPhone(phone);
            m.setAddress(address);
            m.setStatus(status);

            boolean updated = mdao.updateMember(m);

            if (updated) {
                resp.sendRedirect("admin/manage-members.jsp?msg=Member Updated Successfully");
            } else {
                resp.sendRedirect("admin/edit-member.jsp?id=" + id + "&msg=Failed to Update Member");
            }
        }
    }
}

