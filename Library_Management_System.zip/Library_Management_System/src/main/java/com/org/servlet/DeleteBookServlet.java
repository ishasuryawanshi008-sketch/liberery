package com.org.servlet;

import com.org.dao.BookDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/admin/DeleteBookServlet")
public class DeleteBookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        String idStr = request.getParameter("id");
        if (idStr != null) {
            try {
                int id = Integer.parseInt(idStr);
                BookDAO dao = new BookDAO();
                boolean deleted = dao.deleteBook(id);

                if (deleted) {
                    response.sendRedirect(request.getContextPath() + "/admin/manage-books.jsp?msg=deleted");
                } else {
                    response.sendRedirect(request.getContextPath() + "/admin/manage-books.jsp?msg=error");
                }

            } catch (NumberFormatException e) {
                response.sendRedirect(request.getContextPath() + "/admin/manage-books.jsp?msg=error");
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/admin/manage-books.jsp?msg=error");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}
