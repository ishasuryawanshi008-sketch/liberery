package com.org.servlet;

import com.org.dao.DBConnect;
import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/member/ChangePasswordServlet")
public class ChangePasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        int userId = Integer.parseInt(req.getParameter("userId"));
        String newPassword = req.getParameter("newPassword");

        try {
            Connection con = DBConnect.getConnection();
            String sql = "UPDATE user_accounts SET password=? WHERE user_id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, newPassword); // Optional: hash password here
            ps.setInt(2, userId);
            int updated = ps.executeUpdate();

            if(updated > 0){
                resp.sendRedirect("member-profile-page.jsp?msg=passwordchanged");
            } else {
                resp.sendRedirect("member-profile-page.jsp?msg=error");
            }
        } catch(Exception e){
            e.printStackTrace();
            resp.sendRedirect("member-profile-page.jsp?msg=error");
        }
    }
}
