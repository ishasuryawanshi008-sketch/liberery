package com.org.servlet;

import com.org.dao.DBConnect;
import java.sql.*;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/AdminAccessServlet")
public class AdminAccessServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        try (Connection con = DBConnect.getConnection()) {

            PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM admin");
            ResultSet rs = ps.executeQuery();
            rs.next();

            int count = rs.getInt(1);

            if (count == 0) {
                resp.sendRedirect("admin/admin-register.jsp");
            } else {
                resp.sendRedirect("admin/admin-login.jsp");
            }

        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("admin/admin-login.jsp?msg=error");
        }
    }
}
