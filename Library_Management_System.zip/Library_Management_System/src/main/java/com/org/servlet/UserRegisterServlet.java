package com.org.servlet;

import com.org.dao.UserDAO;
import com.org.dao.DBConnect;
import com.org.model.User;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/UserRegisterServlet")
public class UserRegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        User u = new User();
        u.setFullName(name);
        u.setEmail(email);
        u.setPassword(password);     // (For production → hash)
        u.setPhone(null);
        u.setAddress(null);
        u.setRole("member");
        u.setStatus("active");
        u.setProfileImg("default.png");

        UserDAO dao = new UserDAO(DBConnect.getConnection());

        boolean success = dao.registerUser(u);

        if (success) {
            resp.sendRedirect("member/member-login-page.jsp?msg=success");
        } else {
            resp.sendRedirect("member/member-register-page.jsp?msg=error");
        }
    }
}
