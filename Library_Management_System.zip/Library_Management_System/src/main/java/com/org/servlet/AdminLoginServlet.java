package com.org.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import com.org.dao.AdminDAO;
import com.org.model.Admin;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String email = req.getParameter("email");
        String password = req.getParameter("password");

        AdminDAO dao = new AdminDAO();
        Admin admin = dao.login(email, password);

        if(admin != null) {
            HttpSession session = req.getSession();
            session.setAttribute("adminObj", admin);
            session.setAttribute("adminName", admin.getName());
            resp.sendRedirect("admin/admin-dashboard.jsp");
        } else {
            resp.sendRedirect("admin/admin-login.jsp?msg=invalid");
        }
    }
}
