package com.org.servlet.member;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.org.dao.DBConnect;

@WebServlet("/member/PayFineServlet")
public class PayFineServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("memberEmail") == null) {
            response.sendRedirect(request.getContextPath() + "/member-login-page.jsp?msg=loginfirst");
            return;
        }

        String fineIdParam = request.getParameter("fineId");
        if (fineIdParam == null || fineIdParam.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/member/member-fines.jsp?msg=invalid");
            return;
        }

        int fineId = Integer.parseInt(fineIdParam);

        try (Connection con = DBConnect.getConnection()) {

            String sql = "UPDATE fines SET status='paid', paid_date=NOW() WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, fineId);

            int updated = ps.executeUpdate();
            ps.close();

            if (updated > 0) {
                response.sendRedirect(request.getContextPath() + "/member/member-fines.jsp?msg=paid");
            } else {
                response.sendRedirect(request.getContextPath() + "/member/member-fines.jsp?msg=notfound");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/member/member-fines.jsp?msg=error");
        }
    }
}


