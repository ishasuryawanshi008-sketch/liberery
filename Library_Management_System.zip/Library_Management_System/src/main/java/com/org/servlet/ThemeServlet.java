package com.org.servlet;


import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

public class ThemeServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String theme = request.getParameter("theme");
        HttpSession session = request.getSession();
        session.setAttribute("theme", theme);

        response.getWriter().write("OK");
    }
}
