package com.org.servlet.member;

import com.org.dao.DBConnect;
import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/member/UserBookServlet")
public class UserBookServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if(session == null || session.getAttribute("memberEmail") == null) {
            response.sendRedirect("../member-login-page.jsp?msg=loginfirst");
            return;
        }

        String action = request.getParameter("action");
        Connection con = DBConnect.getConnection();

        try {
            String memberEmail = (String) session.getAttribute("memberEmail");

            // Get member ID
            PreparedStatement ps = con.prepareStatement("SELECT id FROM members WHERE email=?");
            ps.setString(1, memberEmail);
            ResultSet rs = ps.executeQuery();
            int memberId = 0;
            if(rs.next()) memberId = rs.getInt("id");

            if("issue".equals(action)) {
                int bookId = Integer.parseInt(request.getParameter("bookId"));

                // Check already issued
                PreparedStatement psCheck = con.prepareStatement(
                    "SELECT * FROM issued_books WHERE member_id=? AND book_id=? AND return_date IS NULL"
                );
                psCheck.setInt(1, memberId);
                psCheck.setInt(2, bookId);
                ResultSet rsCheck = psCheck.executeQuery();
                if(rsCheck.next()) {
                    response.sendRedirect(request.getHeader("referer") + "?msg=AlreadyIssued");
                    return;
                }

                // Insert into issued_books
                PreparedStatement psIssue = con.prepareStatement(
                    "INSERT INTO issued_books(member_id, book_id, issue_date, due_date) VALUES(?,?,CURDATE(),DATE_ADD(CURDATE(), INTERVAL 15 DAY))"
                );
                psIssue.setInt(1, memberId);
                psIssue.setInt(2, bookId);
                psIssue.executeUpdate();

                // Decrease available copies
                PreparedStatement psUpdate = con.prepareStatement(
                    "UPDATE books SET available_copies = available_copies-1 WHERE id=?"
                );
                psUpdate.setInt(1, bookId);
                psUpdate.executeUpdate();

            } else if("return".equals(action)) {
                int issueId = Integer.parseInt(request.getParameter("issueId"));

                // Get book ID for update
                PreparedStatement psBook = con.prepareStatement("SELECT book_id FROM issued_books WHERE id=?");
                psBook.setInt(1, issueId);
                ResultSet rsBook = psBook.executeQuery();
                int bookId = 0;
                if(rsBook.next()) bookId = rsBook.getInt("book_id");

                // Update return_date
                PreparedStatement psReturn = con.prepareStatement(
                    "UPDATE issued_books SET return_date=CURDATE() WHERE id=?"
                );
                psReturn.setInt(1, issueId);
                psReturn.executeUpdate();

                // Increase available copies
                PreparedStatement psUpdate = con.prepareStatement(
                    "UPDATE books SET available_copies = available_copies+1 WHERE id=?"
                );
                psUpdate.setInt(1, bookId);
                psUpdate.executeUpdate();
            }

            response.sendRedirect(request.getHeader("referer"));

        } catch(Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getHeader("referer") + "?msg=Exception");
        }
    }
}

