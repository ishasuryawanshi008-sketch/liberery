package com.org.servlet;

import com.org.dao.DBConnect;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/member/servlet/DeleteNotificationServlet")
public class DeleteNotificationServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("memberEmail") == null) {
            resp.sendRedirect(req.getContextPath() + "/member/member-login-page.jsp");
            return;
        }

        String sid = req.getParameter("id");
        String sPage = req.getParameter("page");
        String category = req.getParameter("category");
        int page = 1;
        try { page = Integer.parseInt(sPage); } catch(Exception ex){}

        if (sid == null) {
            resp.sendRedirect(req.getContextPath() + "/member/member-notifications.jsp?page=" + page + "&category=" + (category==null?"all":category));
            return;
        }

        int id = Integer.parseInt(sid);

        try (Connection con = DBConnect.getConnection()) {
            String memberEmail = (String) session.getAttribute("memberEmail");

            PreparedStatement psMember = con.prepareStatement("SELECT user_id FROM user_accounts WHERE email=?");
            psMember.setString(1, memberEmail);
            ResultSet rs = psMember.executeQuery();
            int memberId = 0;
            if (rs.next()) memberId = rs.getInt("user_id");

            PreparedStatement psDelete = con.prepareStatement(
                "DELETE FROM notifications WHERE id=? AND member_id=?"
            );
            psDelete.setInt(1, id);
            psDelete.setInt(2, memberId);
            psDelete.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }

        resp.sendRedirect(req.getContextPath() + "/member/member-notifications.jsp?page=" + page + "&category=" + (category==null?"all":category));
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
