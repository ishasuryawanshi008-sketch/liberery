package com.org.servlet;

import com.org.dao.UserDAO;
import com.org.dao.DBConnect;
import com.org.model.User;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/UserLoginServlet")
public class UserLoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        String email = req.getParameter("email");
        String password = req.getParameter("password");

        UserDAO dao = new UserDAO(DBConnect.getConnection());
        User user = dao.login(email, password);

        if (user != null) {

            HttpSession session = req.getSession();
            session.setAttribute("memberEmail", user.getEmail());
            session.setAttribute("memberName", user.getFullName());
            session.setAttribute("memberId", user.getId());
            session.setAttribute("userObj", user);

            // redirect based on role
            if (user.getRole().equals("admin")) {
                resp.sendRedirect("admin/index.jsp");
            } else {
                resp.sendRedirect("member/member-dashboard-page.jsp");
            }

        } else {
            resp.sendRedirect("member/member-login-page.jsp?msg=error");
        }
    }
}
