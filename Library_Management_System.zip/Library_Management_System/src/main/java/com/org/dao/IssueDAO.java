package com.org.dao;

import com.org.model.Issue;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class IssueDAO {

    // Get all issued books (not returned)
    public List<Issue> getAllIssuedBooks() {
        List<Issue> list = new ArrayList<>();
        try (Connection con = DBConnect.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM issued_books WHERE return_date IS NULL ORDER BY id DESC")) {
            while (rs.next()) {
                Issue i = new Issue();
                i.setId(rs.getInt("id"));
                i.setMemberId(rs.getInt("member_id"));
                i.setBookId(rs.getInt("book_id"));
                i.setIssueDate(rs.getDate("issue_date"));
                i.setDueDate(rs.getDate("due_date"));
                i.setReturnDate(rs.getDate("return_date"));
                list.add(i);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Get issued book by ID
    public Issue getIssueById(int issueId) {
        Issue i = null;
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM issued_books WHERE id=?")) {
            ps.setInt(1, issueId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                i = new Issue();
                i.setId(rs.getInt("id"));
                i.setMemberId(rs.getInt("member_id"));
                i.setBookId(rs.getInt("book_id"));
                i.setIssueDate(rs.getDate("issue_date"));
                i.setDueDate(rs.getDate("due_date"));
                i.setReturnDate(rs.getDate("return_date"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return i;
    }

    // Return a book
    public boolean returnBook(int issueId, java.util.Date returnDate) {
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement("UPDATE issued_books SET return_date=? WHERE id=?")) {
            ps.setDate(1, new java.sql.Date(returnDate.getTime()));
            ps.setInt(2, issueId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Issue a book
    public boolean issueBook(int memberId, int bookId, java.util.Date issueDate, java.util.Date dueDate) {
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO issued_books (member_id, book_id, issue_date, due_date) VALUES (?,?,?,?)")) {
            ps.setInt(1, memberId);
            ps.setInt(2, bookId);
            ps.setDate(3, new java.sql.Date(issueDate.getTime()));
            ps.setDate(4, new java.sql.Date(dueDate.getTime()));
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Get due date by issue ID
    public java.sql.Date getDueDate(int issueId) {
        java.sql.Date dueDate = null;
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT due_date FROM issued_books WHERE id=?")) {
            ps.setInt(1, issueId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) dueDate = rs.getDate("due_date");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dueDate;
    }
 // ===================== NEW METHODS (DO NOT REMOVE OLD ONES) =====================

 // Admin: View all transactions (issued + returned)
 public List<Issue> getAllTransactions() {
     List<Issue> list = new ArrayList<>();

     String sql = "SELECT * FROM issued_books ORDER BY id DESC";

     try (Connection con = DBConnect.getConnection();
          PreparedStatement ps = con.prepareStatement(sql);
          ResultSet rs = ps.executeQuery()) {

         while (rs.next()) {
             Issue i = new Issue();
             i.setId(rs.getInt("id"));
             i.setMemberId(rs.getInt("member_id"));
             i.setBookId(rs.getInt("book_id"));
             i.setIssueDate(rs.getDate("issue_date"));
             i.setDueDate(rs.getDate("due_date"));
             i.setReturnDate(rs.getDate("return_date"));
             list.add(i);
         }

     } catch (SQLException e) {
         e.printStackTrace();
     }

     return list;
 }

 // Member: View own transactions
 public List<Issue> getTransactionsByMember(int memberId) {
     List<Issue> list = new ArrayList<>();

     String sql = "SELECT * FROM issued_books WHERE member_id=? ORDER BY id DESC";

     try (Connection con = DBConnect.getConnection();
          PreparedStatement ps = con.prepareStatement(sql)) {

         ps.setInt(1, memberId);
         ResultSet rs = ps.executeQuery();

         while (rs.next()) {
             Issue i = new Issue();
             i.setId(rs.getInt("id"));
             i.setMemberId(rs.getInt("member_id"));
             i.setBookId(rs.getInt("book_id"));
             i.setIssueDate(rs.getDate("issue_date"));
             i.setDueDate(rs.getDate("due_date"));
             i.setReturnDate(rs.getDate("return_date"));
             list.add(i);
         }

     } catch (SQLException e) {
         e.printStackTrace();
     }

     return list;
 }

}


