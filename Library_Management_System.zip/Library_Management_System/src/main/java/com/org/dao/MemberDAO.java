package com.org.dao;

import com.org.model.Member;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MemberDAO {

    // Fetch all members
    public List<Member> getAllMembers() {
        List<Member> list = new ArrayList<>();
        try {
            Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM members");
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                Member m = new Member();
                m.setId(rs.getInt("id"));
                m.setName(rs.getString("name"));
                m.setEmail(rs.getString("email"));
                m.setPhone(rs.getString("phone"));
                m.setAddress(rs.getString("address"));
                m.setJoinDate(rs.getTimestamp("join_date"));
                m.setStatus(rs.getString("status"));
                m.setCreatedAt(rs.getTimestamp("created_at"));
                list.add(m);
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Get single member by ID
    public Member getMemberById(int id) {
        Member m = null;
        try {
            Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM members WHERE id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                m = new Member();
                m.setId(rs.getInt("id"));
                m.setName(rs.getString("name"));
                m.setEmail(rs.getString("email"));
                m.setPhone(rs.getString("phone"));
                m.setAddress(rs.getString("address"));
                m.setJoinDate(rs.getTimestamp("join_date"));
                m.setStatus(rs.getString("status"));
                m.setCreatedAt(rs.getTimestamp("created_at"));
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        return m;
    }

    // Add new member
    public boolean addMember(Member m) {
        boolean f = false;
        try {
            Connection con = DBConnect.getConnection();
            String sql = "INSERT INTO members(name,email,phone,address,join_date,status,created_at) VALUES(?,?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, m.getName());
            ps.setString(2, m.getEmail());
            ps.setString(3, m.getPhone());
            ps.setString(4, m.getAddress());
            ps.setTimestamp(5, m.getJoinDate() != null ? m.getJoinDate() : new Timestamp(System.currentTimeMillis()));
            ps.setString(6, m.getStatus());
            ps.setTimestamp(7, m.getCreatedAt() != null ? m.getCreatedAt() : new Timestamp(System.currentTimeMillis()));
            int i = ps.executeUpdate();
            if(i > 0) f = true;
        } catch(Exception e) {
            e.printStackTrace();
        }
        return f;
    }

    // Update member info
    public boolean updateMember(Member m) {
        boolean f = false;
        try {
            Connection con = DBConnect.getConnection();
            String sql = "UPDATE members SET name=?, email=?, phone=?, address=?, join_date=?, status=? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, m.getName());
            ps.setString(2, m.getEmail());
            ps.setString(3, m.getPhone());
            ps.setString(4, m.getAddress());
            ps.setTimestamp(5, m.getJoinDate());
            ps.setString(6, m.getStatus());
            ps.setInt(7, m.getId());
            int i = ps.executeUpdate();
            if(i > 0) f = true;
        } catch(Exception e) {
            e.printStackTrace();
        }
        return f;
    }

    // Update member status only
    public boolean updateStatus(int id, String status) {
        boolean f = false;
        try {
            Connection con = DBConnect.getConnection();
            String sql = "UPDATE members SET status=? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, status);
            ps.setInt(2, id);
            int i = ps.executeUpdate();
            if(i > 0) f = true;
        } catch(Exception e) {
            e.printStackTrace();
        }
        return f;
    }

    // Delete member
    public boolean deleteMember(int id) {
        boolean f = false;
        try {
            Connection con = DBConnect.getConnection();
            String sql = "DELETE FROM members WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            int i = ps.executeUpdate();
            if(i > 0) f = true;
        } catch(Exception e) {
            e.printStackTrace();
        }
        return f;
    }
}
