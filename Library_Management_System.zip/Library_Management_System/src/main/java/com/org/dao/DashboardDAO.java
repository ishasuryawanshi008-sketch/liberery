package com.org.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DashboardDAO {

    public int getTotalBooks() {
        String sql = "SELECT COUNT(*) AS total FROM books";
        try(Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {
            if(rs.next()) return rs.getInt("total");
        } catch(SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public int getTotalMembers() {
        String sql = "SELECT COUNT(*) AS total FROM members";
        try(Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {
            if(rs.next()) return rs.getInt("total");
        } catch(SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public int getTotalIssuedBooks() {
        String sql = "SELECT COUNT(*) AS total FROM issues WHERE return_date IS NULL";
        try(Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {
            if(rs.next()) return rs.getInt("total");
        } catch(SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public int getTotalFines() {
        String sql = "SELECT COUNT(*) AS total FROM fines";
        try(Connection con = DBConnect.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {
            if(rs.next()) return rs.getInt("total");
        } catch(SQLException e) { e.printStackTrace(); }
        return 0;
    }
}

