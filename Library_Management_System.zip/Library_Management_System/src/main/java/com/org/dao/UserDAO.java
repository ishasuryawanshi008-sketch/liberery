package com.org.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.org.model.User;

public class UserDAO {

    private Connection conn;

    public UserDAO(Connection conn) {
        this.conn = conn;
    }

    // -------------------------
    // REGISTER NEW USER
    // -------------------------
    public boolean registerUser(User user) {
        boolean f = false;

        try {
            String sql = "INSERT INTO user_accounts(full_name, email, password, phone, address, role, status, profile_img, total_fines, books_issued, created_at, last_login) "
                    + "VALUES(?,?,?,?,?,?,?,?,?,?,NOW(),NOW())";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, user.getFullName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getPhone());
            ps.setString(5, user.getAddress());
            ps.setString(6, user.getRole());
            ps.setString(7, user.getStatus());
            ps.setString(8, user.getProfileImg());
            ps.setDouble(9, 0.0);
            ps.setInt(10, 0);

            f = ps.executeUpdate() == 1;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return f;
    }

    // -------------------------
    // LOGIN USER
    // -------------------------
    public User login(String email, String password) {
        User user = null;

        try {
            String sql = "SELECT * FROM user_accounts WHERE email=? AND password=? AND status='active'";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, email);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                user = mapUser(rs);

                // update last login
                PreparedStatement ps2 = conn.prepareStatement("UPDATE user_accounts SET last_login=NOW() WHERE id=?");
                ps2.setInt(1, user.getId());
                ps2.executeUpdate();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }

    // -------------------------
    // GET USER BY ID
    // -------------------------
    public User getUserById(int id) {
        User user = null;

        try {
            String sql = "SELECT * FROM user_accounts WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                user = mapUser(rs);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }

    // -------------------------
    // GET ALL USERS (ADMIN PANEL)
    // -------------------------
    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();

        try {
            String sql = "SELECT * FROM user_accounts ORDER BY id DESC";
            PreparedStatement ps = conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapUser(rs));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // -------------------------
    // UPDATE USER STATUS
    // active / inactive
    // -------------------------
    public boolean updateUserStatus(int id, String status) {
        boolean f = false;

        try {
            String sql = "UPDATE user_accounts SET status=? WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, status);
            ps.setInt(2, id);

            f = ps.executeUpdate() == 1;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return f;
    }

    // -------------------------
    // UPDATE USER PROFILE
    // -------------------------
    public boolean updateProfile(User user) {
        boolean f = false;

        try {
            String sql = "UPDATE user_accounts SET full_name=?, phone=?, address=?, profile_img=? WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, user.getFullName());
            ps.setString(2, user.getPhone());
            ps.setString(3, user.getAddress());
            ps.setString(4, user.getProfileImg());
            ps.setInt(5, user.getId());

            f = ps.executeUpdate() == 1;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return f;
    }

    // -------------------------
    // UPDATE FINES
    // -------------------------
    public boolean updateFines(int userId, double fineAmount) {
        boolean f = false;

        try {
            String sql = "UPDATE user_accounts SET total_fines = total_fines + ? WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDouble(1, fineAmount);
            ps.setInt(2, userId);

            f = ps.executeUpdate() == 1;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return f;
    }

    // -------------------------
    // UPDATE BOOK ISSUED COUNT
    // +1 on issue, -1 on return
    // -------------------------
    public boolean updateBooksIssued(int userId, int change) {
        boolean f = false;

        try {
            String sql = "UPDATE user_accounts SET books_issued = books_issued + ? WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, change); // +1 or -1
            ps.setInt(2, userId);

            f = ps.executeUpdate() == 1;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return f;
    }

    // -------------------------
    // DELETE USER
    // -------------------------
    public boolean deleteUser(int id) {
        boolean f = false;

        try {
            String sql = "DELETE FROM user_accounts WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);

            f = ps.executeUpdate() == 1;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return f;
    }

    // -------------------------
    // MAP RESULTSET → USER OBJECT
    // -------------------------
    private User mapUser(ResultSet rs) throws Exception {
        User user = new User();

        user.setId(rs.getInt("id"));
        user.setFullName(rs.getString("full_name"));
        user.setEmail(rs.getString("email"));
        user.setPassword(rs.getString("password"));
        user.setPhone(rs.getString("phone"));
        user.setAddress(rs.getString("address"));
        user.setRole(rs.getString("role"));
        user.setStatus(rs.getString("status"));
        user.setProfileImg(rs.getString("profile_img"));
        user.setTotalFines(rs.getDouble("total_fines"));
        user.setBooksIssued(rs.getInt("books_issued"));
        user.setCreatedAt(rs.getString("created_at"));
        user.setLastLogin(rs.getString("last_login"));

        return user;
    }
}

