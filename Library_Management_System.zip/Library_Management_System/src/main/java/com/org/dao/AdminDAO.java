package com.org.dao;

import java.sql.*;
import com.org.model.Admin;

public class AdminDAO {

    private Connection con;

    // Constructor using DBConnect
    public AdminDAO() {
        try {
            con = com.org.dao.DBConnect.getConnection();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    // 1️⃣ Admin login
    public Admin login(String email, String password) {
        Admin admin = null;
        try {
            String sql = "SELECT * FROM admin WHERE email=? AND password=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                admin = new Admin();
                admin.setId(rs.getInt("id"));
                admin.setName(rs.getString("name"));
                admin.setEmail(rs.getString("email"));
                admin.setPassword(rs.getString("password"));
                admin.setPhone(rs.getString("phone"));
                admin.setAddress(rs.getString("address"));
            }
        } catch(Exception e) { e.printStackTrace(); }
        return admin;
    }

    // 2️⃣ Admin register
    public boolean registerAdmin(String name, String email, String password) {
        boolean registered = false;
        try {
            // Check if email exists
            PreparedStatement check = con.prepareStatement("SELECT * FROM admin WHERE email=?");
            check.setString(1, email);
            ResultSet rs = check.executeQuery();
            if(rs.next()) return false;

            String sql = "INSERT INTO admin(name,email,password) VALUES(?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);
            int i = ps.executeUpdate();
            if(i > 0) registered = true;
        } catch(Exception e) { e.printStackTrace(); }
        return registered;
    }

    // 3️⃣ Get first admin (for settings)
    public Admin getFirstAdmin() {
        Admin admin = null;
        try {
            String sql = "SELECT * FROM admin ORDER BY id ASC LIMIT 1";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                admin = new Admin();
                admin.setId(rs.getInt("id"));
                admin.setName(rs.getString("name"));
                admin.setEmail(rs.getString("email"));
                admin.setPassword(rs.getString("password"));
                admin.setPhone(rs.getString("phone"));
                admin.setAddress(rs.getString("address"));
            }
        } catch(Exception e) { e.printStackTrace(); }
        return admin;
    }

    // 4️⃣ Update admin settings
    public boolean updateAdmin(Admin admin) {
        boolean updated = false;
        try {
            String sql = "UPDATE admin SET name=?, email=?, password=?, phone=?, address=? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, admin.getName());
            ps.setString(2, admin.getEmail());
            ps.setString(3, admin.getPassword());
            ps.setString(4, admin.getPhone());
            ps.setString(5, admin.getAddress());
            ps.setInt(6, admin.getId());
            if(ps.executeUpdate() > 0) updated = true;
        } catch(Exception e) { e.printStackTrace(); }
        return updated;
    }
}

