package com.org.dao;

import com.org.model.Issue;
import com.org.model.Transaction;
import java.sql.*;

public class ReturnDAO {

    // Mark return and auto-insert transaction
    public boolean returnBookByIssueId(int issueId, java.sql.Date returnDate) {
        boolean success = false;
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE issued_books SET return_date=? WHERE id=? AND return_date IS NULL")) {

            ps.setDate(1, returnDate);
            ps.setInt(2, issueId);

            int rows = ps.executeUpdate();
            if (rows > 0) {
                success = true;

                // Get issue details
                IssueDAO issueDao = new IssueDAO();
                Issue issue = issueDao.getIssueById(issueId);

                // Add transaction
                Transaction t = new Transaction();
                t.setMemberId(issue.getMemberId());
                t.setBookId(issue.getBookId());
                t.setAction("returned");
                t.setIssueDate(issue.getIssueDate());
                t.setDueDate(issue.getDueDate());
                t.setReturnDate(returnDate);

                new TransactionDAO().addTransaction(t);
            }

        } catch (SQLException e) { e.printStackTrace(); }

        return success;
    }
}
