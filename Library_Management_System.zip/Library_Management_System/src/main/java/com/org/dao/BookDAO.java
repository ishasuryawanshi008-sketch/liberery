package com.org.dao;

import com.org.model.Book;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {

    // Get all books
    public List<Book> getAllBooks() {
        List<Book> list = new ArrayList<>();
        try (Connection con = DBConnect.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM books ORDER BY id DESC")) {
            while (rs.next()) {
                Book b = new Book();
                b.setId(rs.getInt("id"));
                b.setTitle(rs.getString("title"));
                b.setAuthor(rs.getString("author"));
                b.setPublisher(rs.getString("publisher"));
                b.setCategory(rs.getString("qategory")); // keep your existing DB column
                b.setTotalCopies(rs.getInt("total_copies"));
                b.setAvailableCopies(rs.getInt("available_copies"));
                b.setCreatedAt(rs.getTimestamp("created_at"));
                list.add(b);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Get single book
    public Book getBookById(int id) {
        Book b = null;
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM books WHERE id=?")) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                b = new Book();
                b.setId(rs.getInt("id"));
                b.setTitle(rs.getString("title"));
                b.setAuthor(rs.getString("author"));
                b.setPublisher(rs.getString("publisher"));
                b.setCategory(rs.getString("qategory"));
                b.setTotalCopies(rs.getInt("total_copies"));
                b.setAvailableCopies(rs.getInt("available_copies"));
                b.setCreatedAt(rs.getTimestamp("created_at"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return b;
    }

    // Decrease available copies
    public boolean decreaseCopies(int bookId) {
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE books SET available_copies = available_copies - 1 WHERE id=? AND available_copies > 0")) {
            ps.setInt(1, bookId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Increase available copies
    public boolean increaseCopies(int bookId) {
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE books SET available_copies = available_copies + 1 WHERE id=?")) {
            ps.setInt(1, bookId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete book
    public boolean deleteBook(int id) {
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM books WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Get available copies
    public int getAvailableCopies(int bookId) {
        int copies = 0;
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT available_copies FROM books WHERE id=?")) {
            ps.setInt(1, bookId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) copies = rs.getInt("available_copies");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return copies;
    }

    // Get book_id by issue ID
    public int getBookIdByIssue(int issueId) {
        int bookId = 0;
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT book_id FROM issued_books WHERE id=?")) {
            ps.setInt(1, issueId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) bookId = rs.getInt("book_id");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookId;
    }
}

