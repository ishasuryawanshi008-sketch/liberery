package com.org.dao;

import com.org.model.Fine;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FineDAO {

    // Add fine using issueId
    public void addFineByIds(int issueId, double fineAmount) {
        try (Connection con = DBConnect.getConnection()) {
            String selectSql = "SELECT member_id, book_id FROM issued_books WHERE id=?";
            try (PreparedStatement psSelect = con.prepareStatement(selectSql)) {
                psSelect.setInt(1, issueId);
                try (ResultSet rs = psSelect.executeQuery()) {
                    if (rs.next()) {
                        int memberId = rs.getInt("member_id");
                        int bookId = rs.getInt("book_id");

                        // Check duplicate unpaid fine
                        String checkSql = "SELECT id FROM fines WHERE member_id=? AND book_id=? AND status='unpaid'";
                        try (PreparedStatement psCheck = con.prepareStatement(checkSql)) {
                            psCheck.setInt(1, memberId);
                            psCheck.setInt(2, bookId);
                            try (ResultSet rsCheck = psCheck.executeQuery()) {
                                if (!rsCheck.next()) {
                                    String insertSql = "INSERT INTO fines (member_id, book_id, fine_amount, status) VALUES (?,?,?, 'unpaid')";
                                    try (PreparedStatement psInsert = con.prepareStatement(insertSql)) {
                                        psInsert.setInt(1, memberId);
                                        psInsert.setInt(2, bookId);
                                        psInsert.setDouble(3, fineAmount);
                                        psInsert.executeUpdate();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Get all fines for a member
    public List<Fine> getFinesByMember(int memberId) {
        List<Fine> fines = new ArrayList<>();
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM fines WHERE member_id=?")) {
            ps.setInt(1, memberId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Fine f = new Fine();
                    f.setId(rs.getInt("id"));
                    f.setMemberId(rs.getInt("member_id"));
                    f.setBookId(rs.getInt("book_id"));
                    f.setFineAmount(rs.getDouble("fine_amount"));
                    f.setStatus(rs.getString("status"));
                    fines.add(f);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fines;
    }

    // Get all unpaid fines for member
    public List<Fine> getUnpaidFinesByMember(int memberId) {
        List<Fine> fines = new ArrayList<>();
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM fines WHERE member_id=? AND status='unpaid'")) {
            ps.setInt(1, memberId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Fine f = new Fine();
                    f.setId(rs.getInt("id"));
                    f.setMemberId(rs.getInt("member_id"));
                    f.setBookId(rs.getInt("book_id"));
                    f.setFineAmount(rs.getDouble("fine_amount"));
                    f.setStatus(rs.getString("status"));
                    fines.add(f);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fines;
    }

    // Get all unpaid fines (for admin view)
    public List<Fine> getUnpaidFines() {
        List<Fine> fines = new ArrayList<>();
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM fines WHERE status='unpaid'")) {
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Fine f = new Fine();
                    f.setId(rs.getInt("id"));
                    f.setMemberId(rs.getInt("member_id"));
                    f.setBookId(rs.getInt("book_id"));
                    f.setFineAmount(rs.getDouble("fine_amount"));
                    f.setStatus(rs.getString("status"));
                    fines.add(f);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fines;
    }

    // Mark fine as paid (USE fine id now, NOT issueId)
    public boolean markFineAsPaidById(int fineId) {
        try (Connection con = DBConnect.getConnection()) {
            String updateSql = "UPDATE fines SET status='paid', paid_date=NOW() WHERE id=?";
            try (PreparedStatement ps = con.prepareStatement(updateSql)) {
                ps.setInt(1, fineId);
                int rows = ps.executeUpdate();
                return rows > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
 // Charge overdue fines (Admin action)
    public void chargeOverdueFines(double perDayFine) {

        String sql =
            "SELECT ib.id AS issue_id, ib.member_id, ib.book_id, " +
            "DATEDIFF(CURDATE(), ib.return_date) AS late_days " +
            "FROM issued_books ib " +
            "WHERE ib.return_date < CURDATE() " +
            "AND ib.id NOT IN (" +
            "   SELECT issue_id FROM fines WHERE status='unpaid'" +
            ")";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                int issueId = rs.getInt("issue_id");
                int lateDays = rs.getInt("late_days");

                if (lateDays > 0) {
                    double fineAmount = lateDays * perDayFine;

                    // Reuse your EXISTING method (DO NOT duplicate logic)
                    addFineByIds(issueId, fineAmount);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
 // Get all fines (admin fine transactions)
    public List<Fine> getAllFines() {

        List<Fine> fines = new ArrayList<>();

        String sql = "SELECT * FROM fines ORDER BY id DESC";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Fine f = new Fine();
                f.setId(rs.getInt("id"));
                f.setMemberId(rs.getInt("member_id"));
                f.setBookId(rs.getInt("book_id"));
                f.setFineAmount(rs.getDouble("fine_amount"));
                f.setStatus(rs.getString("status"));
                fines.add(f);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return fines;
    }



}

