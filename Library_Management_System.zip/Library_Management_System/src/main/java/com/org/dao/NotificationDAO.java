package com.org.dao;

import com.org.model.Notification;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NotificationDAO {

    private Connection conn;

    public NotificationDAO() {
        conn = DBConnect.getConnection();
    }

    // Count notifications (with optional category filter)
    public int countNotifications(int memberId, String category) {
        int count = 0;
        try {
            String sql = "SELECT COUNT(*) FROM notifications WHERE member_id=?";
            if (!"all".equalsIgnoreCase(category)) {
                sql += " AND category=?";
            }
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, memberId);
            if (!"all".equalsIgnoreCase(category)) {
                ps.setString(2, category);
            }
            ResultSet rs = ps.executeQuery();
            if (rs.next()) count = rs.getInt(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    // List notifications with pagination
    public List<Notification> listNotifications(int memberId, String category, int offset, int limit) {
        List<Notification> list = new ArrayList<>();
        try {
            String sql = "SELECT id, message, status, created_at, category FROM notifications WHERE member_id=?";
            if (!"all".equalsIgnoreCase(category)) sql += " AND category=?";
            sql += " ORDER BY created_at DESC LIMIT ? OFFSET ?";

            PreparedStatement ps = conn.prepareStatement(sql);
            int paramIndex = 1;
            ps.setInt(paramIndex++, memberId);
            if (!"all".equalsIgnoreCase(category)) ps.setString(paramIndex++, category);
            ps.setInt(paramIndex++, limit);
            ps.setInt(paramIndex, offset);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Notification n = new Notification();
                n.setId(rs.getInt("id"));
                n.setMessage(rs.getString("message"));
                n.setStatus(rs.getString("status"));
                n.setCreatedAt(rs.getTimestamp("created_at"));
                n.setCategory(rs.getString("category"));
                list.add(n);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Delete single notification
    public void deleteNotification(int id, int memberId) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM notifications WHERE id=? AND member_id=?"
            );
            ps.setInt(1, id);
            ps.setInt(2, memberId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Mark all notifications as read
    public void markAllRead(int memberId) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE notifications SET status='read' WHERE member_id=?"
            );
            ps.setInt(1, memberId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
