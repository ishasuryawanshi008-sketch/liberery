package com.org.dao;

import com.org.model.Transaction;
import com.org.dao.DBConnect;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO {

    // Add new transaction
    public boolean addTransaction(Transaction t) {
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO transactions (member_id, book_id, action, issue_date, due_date, return_date, fine) VALUES (?,?,?,?,?,?,?)")) {

            ps.setInt(1, t.getMemberId());
            ps.setInt(2, t.getBookId());
            ps.setString(3, t.getAction());
            ps.setDate(4, t.getIssueDate() != null ? new java.sql.Date(t.getIssueDate().getTime()) : null);
            ps.setDate(5, t.getDueDate() != null ? new java.sql.Date(t.getDueDate().getTime()) : null);
            ps.setDate(6, t.getReturnDate() != null ? new java.sql.Date(t.getReturnDate().getTime()) : null);
            ps.setDouble(7, t.getFine());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    // Admin: get all transactions
    public List<Transaction> getAllTransactions() {
        List<Transaction> list = new ArrayList<>();
        try (Connection con = DBConnect.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM transactions ORDER BY id DESC")) {

            while (rs.next()) {
                Transaction t = new Transaction();
                t.setId(rs.getInt("id"));
                t.setMemberId(rs.getInt("member_id"));
                t.setBookId(rs.getInt("book_id"));
                t.setAction(rs.getString("action"));
                t.setIssueDate(rs.getDate("issue_date"));
                t.setDueDate(rs.getDate("due_date"));
                t.setReturnDate(rs.getDate("return_date"));
                t.setFine(rs.getDouble("fine"));
                t.setCreatedAt(rs.getTimestamp("created_at"));
                list.add(t);
            }

        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    // Member: get only own transactions
    public List<Transaction> getTransactionsByMember(int memberId) {
        List<Transaction> list = new ArrayList<>();
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT * FROM transactions WHERE member_id=? ORDER BY id DESC")) {

            ps.setInt(1, memberId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Transaction t = new Transaction();
                t.setId(rs.getInt("id"));
                t.setMemberId(rs.getInt("member_id"));
                t.setBookId(rs.getInt("book_id"));
                t.setAction(rs.getString("action"));
                t.setIssueDate(rs.getDate("issue_date"));
                t.setDueDate(rs.getDate("due_date"));
                t.setReturnDate(rs.getDate("return_date"));
                t.setFine(rs.getDouble("fine"));
                t.setCreatedAt(rs.getTimestamp("created_at"));
                list.add(t);
            }

        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }
}

