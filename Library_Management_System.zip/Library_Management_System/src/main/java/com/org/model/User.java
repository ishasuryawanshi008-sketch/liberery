package com.org.model;

public class User {

    private int id;
    private String fullName;
    private String email;
    private String password;
    private String phone;
    private String address;
    private String role;        // admin / member
    private String status;      // active / inactive
    private String profileImg;

    private double totalFines;  // NEW
    private int booksIssued;    // NEW
    private String createdAt;   // NEW
    private String lastLogin;   // NEW

    public User() {}

    public User(int id, String fullName, String email, String password, String phone, String address,
                String role, String status, String profileImg, double totalFines,
                int booksIssued, String createdAt, String lastLogin) {

        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.address = address;
        this.role = role;
        this.status = status;
        this.profileImg = profileImg;
        this.totalFines = totalFines;
        this.booksIssued = booksIssued;
        this.createdAt = createdAt;
        this.lastLogin = lastLogin;
    }

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getProfileImg() { return profileImg; }
    public void setProfileImg(String profileImg) { this.profileImg = profileImg; }

    public double getTotalFines() { return totalFines; }
    public void setTotalFines(double totalFines) { this.totalFines = totalFines; }

    public int getBooksIssued() { return booksIssued; }
    public void setBooksIssued(int booksIssued) { this.booksIssued = booksIssued; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    public String getLastLogin() { return lastLogin; }
    public void setLastLogin(String lastLogin) { this.lastLogin = lastLogin; }
}

