// ================================
// Contact Form Success Handling
// ================================
const contactForm = document.getElementById("contactForm");
const contactSuccess = document.getElementById("contactSuccess");

if(contactForm) {
    contactForm.addEventListener("submit", function(e){
        e.preventDefault(); // prevent actual form submission

        // Show success message
        contactSuccess.classList.remove("d-none");

        // Optional: Reset form
        contactForm.reset();

        // Fade out message after 3 seconds
        setTimeout(() => {
            contactSuccess.classList.add("d-none");
        }, 3000);
    });
}

// ================================
// Member Login Success Handling
// ================================
const loginForm = document.getElementById("loginForm");
const loginSuccess = document.getElementById("loginSuccess");

if(loginForm) {
    loginForm.addEventListener("submit", function(e){
        e.preventDefault(); // prevent actual form submission

        // Show success message
        loginSuccess.classList.remove("d-none");

        // Optional: Reset form
        loginForm.reset();

        // Fade out message after 3 seconds
        setTimeout(() => {
            loginSuccess.classList.add("d-none");
        }, 3000);
    });
}

