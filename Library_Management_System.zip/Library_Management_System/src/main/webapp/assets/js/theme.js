const toggle = document.getElementById('themeToggle');
const savedTheme = localStorage.getItem("admin-theme");

if(savedTheme === "dark"){
    document.body.classList.add("dark-mode");
    if(toggle) toggle.checked = true;
}

toggle.addEventListener('change', () => {
    if(toggle.checked){
        document.body.classList.add('dark-mode');
        localStorage.setItem('admin-theme','dark');
    } else {
        document.body.classList.remove('dark-mode');
        localStorage.setItem('admin-theme','light');
    }
});
